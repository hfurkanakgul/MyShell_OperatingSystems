#include <stdlib.h>

int main(int argc, char* argv[])
{
   return (atoi(argv[1])+atoi(argv[2]));
}
