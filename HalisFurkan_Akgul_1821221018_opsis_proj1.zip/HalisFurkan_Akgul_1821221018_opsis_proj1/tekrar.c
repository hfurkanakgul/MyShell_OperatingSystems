int main(int argc, char const *argv[])
{
    for (int i = 0; i <atoi(argv[2]); i++)
    {
        printf("%s \n",argv[1]);
    }
    
    return 0;
}
